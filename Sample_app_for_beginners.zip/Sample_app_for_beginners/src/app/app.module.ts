import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { ProductListComponent } from './components/products/product-list/product-list.component';
import { ChildComponent } from './components/child/child.component';
import { TemplateDrivenLoginFormComponent } from './components/template-driven-login-form/template-driven-login-form.component';
import { DirectivesExampeComponent } from './components/directives-example/directives-exampe.component';
import { DataBindingComponent } from './components/data-binding/data-binding.component';
import { ContactUsComponent } from './components/contact-us/contact-us.component';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { AboutComponent } from './components/about/about.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HighlightDirective } from './directives/highlight.directive';
import { MyNgIfDirective } from './directives/myNgIf.directive';
import { ParentComponent } from './components/parent/parent.component';
import { HttpClientModule } from '@angular/common/http';
import { LoginComponent } from './components/login/login.component';
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutComponent,
    ContactUsComponent,
    DataBindingComponent,
    DirectivesExampeComponent,
    MyNgIfDirective,
    HighlightDirective,
    TemplateDrivenLoginFormComponent,
    ParentComponent,
    ChildComponent,
    LoginComponent,
    ProductListComponent,
    PageNotFoundComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
