import { Component, OnInit } from '@angular/core';
import { NgForm, FormControl, FormGroup } from '../../../../node_modules/@angular/forms';

@Component({
  selector: 'app-template-driven-login-form',
  templateUrl: './template-driven-login-form.component.html',
  styleUrls: ['./template-driven-login-form.component.css']
})
export class TemplateDrivenLoginFormComponent implements OnInit {
  profileForm = new FormGroup({
    firstName: new FormControl(''),
    lastName: new FormControl(''),
  });
  constructor() { }
  ngOnInit() {
  }
  model: any = {
    firstName: '',
    lastName: '',
    email: '',
    password: ''
  };

  onSubmit(form: NgForm) {
    alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.model));
    this.model = {};
  }
}
