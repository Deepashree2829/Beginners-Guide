import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {

  productsParent: any = [];
  valueParent: any = 'Deepa';
  constructor() { }

  ngOnInit() {
    this.productsParent = [
      { name: 'Mobile', code: 1 },
      { name: 'Laptop', code: 2 },
      { name: 'Charger', code: 3 },
      { name: 'Car', code: 4 },
      { name: 'Bike', code: 5 }
    ]
  }
}
