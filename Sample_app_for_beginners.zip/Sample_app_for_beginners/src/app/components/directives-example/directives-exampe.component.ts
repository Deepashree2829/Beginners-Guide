import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directives-exampe',
  templateUrl: './directives-exampe.component.html',
  styleUrls: ['./directives-exampe.component.css']
})
export class DirectivesExampeComponent implements OnInit {
  // Inbuilt Attribute Directives
  flag: boolean = true; // ngClass
  address = 'Deepa'; // ngModel
  // Inbuilt Structural Directives
  products: any = [];
  // Custom Attribute directive
  color: string = '';
  // Custom Structural Directive
  condition = false;
  name = 'Lee';
  constructor() { }

  ngOnInit() {
    this.products = [
      { name: 'ABC'},
      { name: 'KML'},
      { name: 'XYZ'}
    ]
  }

}
