import { AddProductModel } from './../product.model';
import { ProductsService } from './../products.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '../../../../../node_modules/@angular/forms';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  headers: any = [];
  productsList: any = [];
  showAddPopup = false;
  addProductModel = {} as AddProductModel;
  addProductForm = this.fb.group({
    name: ['', Validators.required],
    contact: ['', Validators.required],
    country: ['', Validators.required]
  });
  mode: string = 'add';
  constructor(private productService: ProductsService, private fb: FormBuilder) { }

  ngOnInit() {
    this.headers = [  'Name', 'Contact', 'Country', 'Action'];
    this.getProductList();
  }

  getProductList() {
    this.productService.getProductList().subscribe((response: any) => {
      this.productsList = response.data;
    })
  }
  addProduct() {
    this.showAddPopup = true;
  }
  onSubmit() {
    alert(JSON.stringify(this.addProductModel));
    this.productService.addProduct(this.addProductModel, this.mode).subscribe((data: any) => {
      console.log('Successfully added');
    })
  }
  editProduct(product: any) {
    this.mode = 'edit';
    this.productService.getProductById(product).subscribe((response: any) => {
      this.showAddPopup = true;
      this.addProductModel = response[0];
    })
  }
  deleteProduct(product: any) {
    this.productService.deleteProductById(product).subscribe((response: any) => {
      alert('Deleted');
    })
  }
}
