import { Injectable } from '@angular/core';
import { HttpClient } from '../../../../node_modules/@angular/common/http';

const apiURL = 'http://localhost:3000/data/';
@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  constructor(private http: HttpClient) { }

  getProductList() {
    return this.http.get('assets/json/product-list.json')
  }
  addProduct(product: any, mode: string) {
    if(mode === 'add') {
      return this.http.post(apiURL, product)
    } else {
      return this.http.put(apiURL + product.id , product)
    }
  }
  getProductById(product: any) {
    return this.http.get(apiURL + '?id=' + product.id)
  }
  deleteProductById(product: any) {
    return this.http.delete(apiURL + product.id , product)
  }
}
