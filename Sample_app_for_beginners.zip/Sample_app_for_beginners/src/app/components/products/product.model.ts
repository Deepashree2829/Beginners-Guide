export interface AddProductModel {
    id: number,
    name: string,
    contact: number,
    country: string
}
