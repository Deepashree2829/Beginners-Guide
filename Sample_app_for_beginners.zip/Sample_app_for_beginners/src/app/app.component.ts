import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angular11-app'; // variable
  header = 'Angular11 Application'
  submitDisable = false;
  address = 'Bangalore';
  save() {
    this.submitDisable = true;
    this.address = 'Dehli';
  }
}
